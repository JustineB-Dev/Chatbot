# Chatbot

Implemented Chatbot using Langflow in local with ollama (ollama run gemma3:1b)

(pending)

-Pdf and file storing 
-history
-Retrieval Augmented Generation (RAG)
